const express = require('express');
const router = express.Router();
const Screenshot = require('../models/screenshotModel');
const bodyParser = require('body-parser');

router.use(bodyParser.json());

// POST /screenshots
router.post('/', async (req, res) => {
  const { userId, imageUrl } = req.body;

  try {
    const newScreenshot = new Screenshot({ userId, imageUrl });
    await newScreenshot.save();
    res.status(201).json(newScreenshot);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /screenshots/:userId
router.get('/:userId', async (req, res) => {
  const userId = req.params.userId;

  try {
    const screenshots = await Screenshot.find({ userId });
    res.json(screenshots);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
