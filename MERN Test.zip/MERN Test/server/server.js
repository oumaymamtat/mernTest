const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const screenshotsRouter = require('./routes/screenshots');
const cors = require('cors');

const app = express();
const port = 3000;

// Enable CORS for all origins
app.use(cors());

// Middleware pour parser le corps des requêtes en JSON
app.use(bodyParser.json());

// Connexion à MongoDB via Mongoose
mongoose.connect('mongodb://127.0.0.1/screenshotsDB');

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'Erreur de connexion à MongoDB :'));
db.once('open', () => {
  console.log('Connecté à MongoDB');
});

// Utilisation des routes définies dans routes/screenshots.js
app.use('/screenshots', screenshotsRouter);

// Démarrage du serveur Express
app.listen(port, () => {
  console.log(`Serveur démarré sur http://localhost:${port}`);
});
