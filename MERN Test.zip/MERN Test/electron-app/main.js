const { app, BrowserWindow, ipcMain, desktopCapturer, screen, nativeImage } = require('electron');
const axios = require('axios');
const path = require('path');
const fs = require('fs');

let mainWindow;
let screenshotInterval;
let capturingScreenshots = false;

function createWindow() {
    mainWindow = new BrowserWindow({
        width: 800,
        height: 600,
        webPreferences: {
            nodeIntegration: true,
            contextIsolation: false,
        }
    });

    mainWindow.loadFile('index.html');

    mainWindow.on('closed', () => {
        mainWindow = null;
    });
}

app.on('ready', createWindow);

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        app.quit();
    }
});

app.on('activate', () => {
    if (mainWindow === null) {
        createWindow();
    }
});

ipcMain.on('startCapture', () => {
    startScreenshots(5); // Capture every 5 seconds (adjustable)
});

ipcMain.on('stopCapture', () => {
    stopScreenshots();
});

function startScreenshots(intervalInSeconds) {
    if (capturingScreenshots) return; // Prevent starting another interval if already capturing
    capturingScreenshots = true;

    screenshotInterval = setInterval(() => {
        const displays = screen.getAllDisplays();
        const primaryDisplay = screen.getPrimaryDisplay();

        const captureDisplay = displays.find(display => display.id === primaryDisplay.id);

        if (!captureDisplay) {
            console.error('No suitable display found');
            return;
        }

        const screenshotPath = path.join(app.getPath('temp'), `screenshot_${Date.now()}.png`);

        mainWindow.capturePage().then(image => {
            const screenshot = image.toPNG();

            fs.writeFile(screenshotPath, screenshot, err => {
                if (err) {
                    console.error('Error saving screenshot:', err);
                } else {
                    console.log('Screenshot captured:', screenshotPath);
                    sendScreenshotToBackend('user123', screenshotPath); // Replace 'user123' with actual userId
                }
            });
        }).catch(err => {
            console.error('Error capturing screenshot:', err);
        });

    }, intervalInSeconds * 1000);
}

function stopScreenshots() {
    clearInterval(screenshotInterval);
    capturingScreenshots = false; // Reset capturing flag
    sendTerminationMessage();
}

function sendTerminationMessage() {
    mainWindow.webContents.send('screenshotTerminated', 'Screenshot capturing terminated.');
}

function sendScreenshotToBackend(userId, screenshotPath) {
    const url = 'http://localhost:3000/screenshots';

    // Create form data with userId and screenshot file
    const formData = new FormData();
    formData.append('userId', userId);
    formData.append('screenshot', fs.createReadStream(screenshotPath));

    axios.post(url, formData, {
        headers: {
            'Content-Type': 'multipart/form-data',
        },
    }).then(response => {
        console.log('Screenshot uploaded successfully:', response.data);
        mainWindow.webContents.send('screenshotUploaded', screenshotPath); // Send IPC message to renderer process
    }).catch(error => {
        console.error('Error uploading screenshot:', error);
    });
}
