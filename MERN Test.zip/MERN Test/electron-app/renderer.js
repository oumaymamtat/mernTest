const { ipcRenderer } = require('electron');

const startCaptureButton = document.getElementById('startCapture');
const stopCaptureButton = document.getElementById('stopCapture');
const messageContainer = document.getElementById('messageContainer');

startCaptureButton.addEventListener('click', () => {
    ipcRenderer.send('startCapture');
    startCaptureButton.disabled = true; // Disable start button when clicked
    stopCaptureButton.disabled = false; // Enable stop button
});

stopCaptureButton.addEventListener('click', () => {
    ipcRenderer.send('stopCapture');
    startCaptureButton.disabled = false; // Enable start button
    stopCaptureButton.disabled = true; // Disable stop button when clicked
});

ipcRenderer.on('screenshotUploaded', (event, screenshotPath) => {
    // Display all messages in the message container
    const message = `Screenshot uploaded successfully: ${screenshotPath}`;
    appendMessage(message);
});

ipcRenderer.on('screenshotTerminated', (event, message) => {
    appendMessage(message);
});

function appendMessage(message) {
    const div = document.createElement('div');
    div.textContent = message;
    messageContainer.appendChild(div);
}
