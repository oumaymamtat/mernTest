import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ScreenshotsPage = ({ userId }) => {
    const [screenshots, setScreenshots] = useState([]);

    useEffect(() => {
        const fetchScreenshots = async () => {
            try {
                const response = await axios.get(`http://localhost:3000/screenshots/${userId}`);
                setScreenshots(response.data);
            } catch (error) {
                console.error('Error fetching screenshots:', error);
            }
        };

        fetchScreenshots();
    }, [userId]);

    return (
        <div>
            <h1>Screenshots</h1>
            <div className="screenshots-list">
                {screenshots.map((screenshot, index) => (
                    <div key={index} className="screenshot-item">
                        <p>{screenshot.imageUrl}</p>
                        <img src={screenshot.imageUrl} />
                    </div>
                ))}
            </div>
        </div>
    );
};

export default ScreenshotsPage;
