import React, { useRef, useState } from 'react';
import { useScreenshot } from 'use-react-screenshot';
import axios from 'axios';

const CaptureControl = ({ userId }) => {
  const ref = useRef(null);
  const [capturedImage, takeScreenshot] = useScreenshot();
  const [imageURL, setImageURL] = useState(null);

  const captureImage = async () => {
    try {
      const image = await takeScreenshot(ref.current);
      setImageURL(image);
      await sendImageToBackend(image);
    } catch (error) {
      console.error('Error capturing or saving screenshot:', error);
    }
  };

  const sendImageToBackend = async (imageData) => {
    try {
      // Replace with your backend endpoint for saving images
      const response = await axios.post('http://localhost:3000/screenshots', {
        userId,
        imageUrl: imageData,
      });
      console.log('Image saved successfully:', response.data);
    } catch (error) {
      console.error('Error saving image to backend:', error);
    }
  };

  return (
    <div>
      <div>
        <button style={{ marginBottom: '10px' }} onClick={captureImage}>
          Capture and Save
        </button>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        {imageURL && (
          <div style={{ marginBottom: '10px' }}>
            <h3>Latest Captured Image:</h3>
            <img src={imageURL} alt="Captured Screenshot" style={{ maxWidth: '100%' }} />
          </div>
        )}
        <div ref={ref} style={{ border: '1px solid #ccc', padding: '10px', maxWidth: '400px' }}>
          <h1>use-react-screenshot</h1>
          <p>
            <strong>Hook by @vre2h which allows creating screenshots</strong>
          </p>
        </div>
      </div>
    </div>
  );
};

export default CaptureControl;
