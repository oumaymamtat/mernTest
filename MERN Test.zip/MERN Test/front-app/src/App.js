import React from 'react';
import './App.css';
import ScreenshotsPage from './ScreenshotsPage';
import CaptureControl from './CaptureControl';

function App() {
    const userId = '120';

    return (
        <div className="App">
            <h1>Screen Capture App</h1>
            <CaptureControl userId={userId} />
            <ScreenshotsPage userId={userId} />
        </div>
    );
}

export default App;
